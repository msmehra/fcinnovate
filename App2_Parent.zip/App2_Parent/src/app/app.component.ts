import { Component, Input, OnInit } from '@angular/core';
import { WebSocketService } from './web-socket.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Websocket Angular client ';
  userName: string='';
  message: string='';
  output: any[] = [];
  feedback: string='';

  constructor(private webSocketService: WebSocketService) { }
  ngOnInit(): void {
    this.webSocketService.listen('typing').subscribe((data) => this.updateFeedback(data));
    this.webSocketService.listen('chat').subscribe((data) => this.updateMessage(data));
  }

  messageTyping(): void {
    //debugger;
    this.webSocketService.emit('typing', this.userName);
  }

  sendMessage(): void {
    //debugger;
    this.webSocketService.emit('chat', {
      message: this.message,
      handle: this.userName
    });
    this.message = "";
  }

  updateMessage(data:any) {
    //debugger;
    this.feedback = '';
    if(!!!data) return;
    console.log(`${data.handle} : ${data.message}`);
    this.output.push(data);
  }

  updateFeedback(data: any){
    //debugger;
    this.feedback = `${data} is typing a message`;
  }
}
